"""Made by packaging/web/build.py: what the conversation code takes from haven/activities.py, for the page."""

SIGHTS = {'pond': 'the pond', 'fire': 'the fire', 'butterfly': 'a butterfly', 'flower': 'the flowers'}
