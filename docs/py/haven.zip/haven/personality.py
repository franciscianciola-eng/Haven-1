"""Made by packaging/web/build.py: what the conversation code takes from haven/personality.py, for the page."""

TRAITS = ('curious', 'playful', 'brave', 'friendly', 'cheerful', 'calm')
