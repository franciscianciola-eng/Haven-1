"""Made by packaging/web/build.py: what the conversation code takes from haven/mind.py, for the page."""

POWERS = {'food': ('bounty', 'found food everywhere'), 'sun': ('sun', 'felt the sun come out'), 'butterflies': ('butterflies', 'saw butterflies come'), 'heal': ('healed', 'was healed'), 'storm': ('storm', 'was caught in a storm'), 'heat': ('heat wave', 'felt a heat wave come'), 'snow': ('snowstorm', 'was caught in a snowstorm'), 'fire': ('wildfire', 'saw a fire spread'), 'quake': ('quake', 'felt the ground shake'), 'blight': ('blight', 'saw the food wither'), 'thorns': ('thorns grew', 'saw thorns grow'), 'hurt': ('hurt by you', 'was hurt by you')}
CHEMICALS = ('dopamine', 'noradrenaline', 'serotonin', 'acetylcholine', 'oxytocin')


def need_words(need: int, level: float, cold: bool) -> str:
    if level < 0.15:
        return "comfortable"
    amount = "a little " if level < 0.35 else "very " if level > 0.7 else ""
    word = ("hungry", "cold" if cold else "hot", "hurt", "tired")[need]
    return f"{amount}{word}"


class Mind:  # (the page's mind is browser.Mind)
    pass
