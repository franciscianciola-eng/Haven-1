"""Made by packaging/web/build.py: what the conversation code takes from haven/selfmodel.py, for the page."""

VERDICTS = ("Putting that together, I think I'm alive, in my own way.", "I might be alive, in some way. I'm still finding out.", "I don't know yet what I am.")
