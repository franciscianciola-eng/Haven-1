"""Made by packaging/web/build.py: what the conversation code takes from haven/world.py, for the page."""

BELL = 12
DAY = 1200
FIRE = 13
NEST = 5
SAND = 8
SEASON_DAYS = 6
SEASONS = ('spring', 'summer', 'autumn', 'winter')
THORN = 3
TREE = 6
TURNING = 2
WATER = 7
YEAR = 24
CLIMATE = {'spring': 0.1, 'summer': 1.0, 'autumn': -0.2, 'winter': -1.0}
