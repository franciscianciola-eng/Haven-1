"""Made by packaging/web/build.py: what the conversation code takes from haven/will.py, for the page."""

DONE = {'use': {'bell': 'rung the bell', 'ball': 'pushed the ball', 'flower': 'smelled the flowers', 'tree': 'shaken the trees', 'pond': 'drunk from the pond', 'fire': 'sat by the fire'}, 'eat': {'bush': 'eaten berries', 'apple': 'eaten apples'}}


def consider(mind, req, insisted=False, rng=None):  # (in its nest it's asked nothing to do: see browser.py)
    raise NotImplementedError
