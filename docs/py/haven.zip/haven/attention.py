"""Made by packaging/web/build.py: what the conversation code takes from haven/attention.py, for the page."""

GOALS = ('food', 'warmth', 'healing', 'sleep', 'explore', 'play')
