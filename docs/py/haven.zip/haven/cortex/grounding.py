"""Made by packaging/web/build.py: what the conversation code takes from haven/cortex/grounding.py, for the page."""

def mind_state(mind):
    return [mind.state()]  # (browser.Mind.state: the workspace tokens, flattened)


def moment_of(mind):
    return {}
