"""Made by packaging/web/build.py: what the conversation code takes from haven/workspace.py, for the page."""

D = 44
SOURCES = ('vision', 'smell', 'touch', 'body', 'hearing', 'memory', 'imagination', 'thought')
Q = 24
QUALITY = slice(8, 32, None)
DRIVES = slice(34, 38, None)
AFFECT = slice(38, 40, None)
CONFIDENCE = 40
IGNITION = 0.35
DECAY = 0.9
