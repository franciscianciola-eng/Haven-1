"""Made by packaging/web/build.py: the little of numpy the conversation code uses."""

def argmax(values):
    values = list(values)
    return max(range(len(values)), key=values.__getitem__)


def mean(values):
    values = list(values)
    return sum(values) / len(values) if values else float('nan')


def clip(value, low, high):
    return min(max(value, low), high)
